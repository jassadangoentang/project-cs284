import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ShowQueueInVer2 extends JFrame {
	private JPanel shopN;
	private JPanel gPanel;
	private JPanel p1;
	private JPanel p2;
	private JPanel p3;;
	public JLabel[] l1;
	public JLabel[] l2;
	public JLabel[] l3;
	private ImageIcon icon;
	private ImageIcon icon2;
	private ImageIcon zone2;
	private ImageIcon zone4;
	private ImageIcon zone8;
	private int table2;
	private int table4;
	private int table8;
	private int cMax = 0;
	private int numTable = 1;
	private int numTable4 = 1, numTable8 = 1;

	public ShowQueueInVer2(int t2, int t4, int t8) {
		table2 = t2;
		table4 = t4;
		table8 = t8;
		int[] m = { table2, table4, table8 };
		for (int i = 0; i < 3; i++) {
			if (m[i] > cMax) {
				cMax = m[i];
			}
		}
		cMax = cMax + 1;
		icon2 = new ImageIcon("bg1.jpg");

		zone2 = new ImageIcon("zone2.jpg");
		zone4 = new ImageIcon("zone3.jpg");
		zone8 = new ImageIcon("zone4.jpg");

		shopN = new JPanel();
		gPanel = new JPanel();

		p1 = new JPanel();
		p1.setLayout(new GridLayout(cMax, 0));
		p1.setBackground(Color.DARK_GRAY);

		p2 = new JPanel();
		p2.setLayout(new GridLayout(cMax, 0));

		p2.setBackground(Color.DARK_GRAY);

		p3 = new JPanel();
		p3.setLayout(new GridLayout(cMax, 0));
		p3.setBackground(Color.DARK_GRAY);

		l1 = new JLabel[cMax];
		l2 = new JLabel[cMax];
		l3 = new JLabel[cMax];

		Font font = new Font("Courier", Font.BOLD, 35);
		Font font2 = new Font("Courier", Font.BOLD, 30);

		for (int i = 0; i < table2 + 1; i++) { // p1
			if (i == 0) {
				l1[i] = new JLabel() {
					public void paintComponent(Graphics g) {
						Dimension size = l1[0].getSize();
						Image resized = zone2.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(resized).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};

				l1[i].setFont(font);
				l1[i].setForeground(Color.white);
				l1[i].setText("  Zone A");
				p1.add(l1[i]);
			} else {
				l1[i] = new JLabel() {
					public void paintComponent(Graphics g) {
						Dimension size = l1[0].getSize();
						Image resized = icon2.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(resized).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};

				l1[i].setOpaque(false);
				l1[i].setFont(font2);
				l1[i].setForeground(Color.WHITE);
				if (i <= table2) {
					l1[i].setText("Table" + numTable + " :");
					numTable++;
				}
				getContentPane().add(l1[i]);
				p1.add(l1[i]);
			}
		}

		// ------------------------------------------------------------------
		for (int i = 0; i < table4 + 1; i++) { // p2
			if (i == 0) {
				l2[i] = new JLabel() {
					public void paintComponent(Graphics g) {
						Dimension size = l2[0].getSize();
						Image resized = zone4.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(resized).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};

				l2[i].setFont(font);
				l2[i].setForeground(Color.WHITE);
				l2[i].setText("  Zone B");
				p2.add(l2[i]);
			} else {
				l2[i] = new JLabel() {
					public void paintComponent(Graphics g) {
						Dimension size = l2[0].getSize();
						Image resized = icon2.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(resized).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};

				l2[i].setOpaque(false);
				l2[i].setFont(font2);
				l2[i].setForeground(Color.WHITE);
				if (i <= table4) {

					l2[i].setText("Table" + numTable4 + " :");
					numTable4++;
				}
				getContentPane().add(l2[i]);
				p2.add(l2[i]);
			}
		}
		// ----------------------------------------------------------------
		for (int i = 0; i < table8 + 1; i++) { // p2
			if (i == 0) {
				l3[i] = new JLabel() {
					public void paintComponent(Graphics g) {
						Dimension size = l3[0].getSize();
						Image resized = zone8.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(resized).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};

				l3[i].setFont(font);
				l3[i].setForeground(Color.WHITE);
				l3[i].setText("  Zone C");
				p3.add(l3[i]);
			} else {
				l3[i] = new JLabel() {
					public void paintComponent(Graphics g) {
						Dimension size = l2[0].getSize();
						Image resized = icon2.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(resized).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};

				l3[i].setOpaque(false);
				l3[i].setFont(font2);
				l3[i].setForeground(Color.WHITE);
				if (i <= table8) {
					l3[i].setText("Table" + numTable8 + " :");
					numTable8++;
				}
				getContentPane().add(l3[i]);
				p3.add(l3[i]);
			}
		}
		// ----------------------------------------------------------------

		gPanel.setLayout(new GridLayout(0, 3));
		gPanel.setBackground(Color.DARK_GRAY);
		gPanel.add(p1);
		gPanel.add(p2);
		gPanel.add(p3);

	}

	public JPanel getgPanel() {
		return gPanel;
	}

	public JLabel SetTable2(String word, int index) {
		l1[index].setText(word);
		return l1[index];
	}

	public void SetTable4(String word, int index) {
		l2[index].setText(word);

	}

	public void SetTable8(String word, int index) {
		l3[index].setText(word);

	}

}
