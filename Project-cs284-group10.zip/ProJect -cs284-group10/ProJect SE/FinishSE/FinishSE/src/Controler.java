import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.border.TitledBorder;

public class Controler extends JFrame implements ActionListener {

	private Queue customer;

	///////////////////////////////////////////////
	private Queue customerOut2;
	private Queue customerOut4;
	private Queue customerOut8;
	private Queue customerIn2;
	private Queue customerIn4;
	private Queue customerIn8;
	///////////////////////////////////////////////

	private Timer timer;
	private JLabel T2,T4,T8;
	private JTabbedPane TABTag;// BIGtab
	private JPanel ManagerTab;// tab1
	private JPanel QueueTab;// tab2
	private JPanel IncreasrTab;// tab3
	private JPanel ChangeTimeTab;// tab4
	private JPanel PanelOfficer;// **in tab1
	private JPanel PanelShowQ;// **in tab 1
	private JLabel Amount;// in PanelOfficer
	private JTextField InputAmount;// in PanelOfficer
	private JTextField InputPhone;// in PanelOfficer
	private JLabel Number;// in PanelOfficer
	private JLabel Phone;// in PanelOfficer
	private JLabel ShowTable2;// in PanelOfficer
	private JLabel ShowTable4;// in PanelOfficer
	private JLabel ShowTable8;// in PanelOfficer
	private JButton[] btn;//// in PanelOfficer
	private JTextField ShowJong;
	private JPanel ShowQ2;
	private JPanel ShowQ4;
	private JPanel ShowQ8;
	private JButton btnDelete;
	private JButton btnKeep;
	private JTextField DeleateQ;
	private JLabel DeleteQQLable;
	private JPanel PanelDelete;
	private JLabel PleasePutLable;
	private JButton btnConferm;
	private JPanel PanelDelete2;
	private JButton addMail;
	private Person person;
	private ArrayList<String> dataList2, dataList4, dataList8;
	private int checkQueue;
	JLabel showQTdai = new JLabel("     0");
	JLabel iDNumber1 = new JLabel();
	JLabel iDNumber2 = new JLabel();
	JLabel iDNumber3 = new JLabel();
	JPanel gg = new JPanel();
	int set2 = 1, set4 = 1, set8 = 1;
	RemainingTime RT;/// ShowTime
	ShowQueueOut queueOutStore;
	int QQ2 = 1, QQ4 = 1, QQ8 = 1;
	//////////////////////////////////////////////////////////////
	int deNum = 1, inAmount = 0, inPhone = 0, queue = 1, amount = 0, tmptime, q2 = 0, q4 = 0, q8 = 0, qt = 0;
	String email, phone = "", delete = "";
	int halfHour=30;
	//////////////////////////////////////////////////////////////

	public Controler() {

		this.customerOut2 = new Queue();
		this.customerOut4 = new Queue();
		this.customerOut8 = new Queue();
		this.customerIn2 = new Queue();
		this.customerIn4 = new Queue();
		this.customerIn8 = new Queue();

		AddTable inCreat = new AddTable();
		// RT = new
		// RemainingTime(inCreat.mg.keepNum,inCreat.mg.keepNum2,inCreat.mg.keepNum3);
		RT = new RemainingTime(5, 5, 5);

		showQTdai.setForeground(new Color(204, 255, 255));
		gg.setLayout(new GridLayout(2, 0));
		showQTdai.setBackground(Color.WHITE);
		///////////////////////////////////////
		this.timer = new Timer(60000, this);
		timer.start();

		this.customer = new Queue();
		dataList2 = new ArrayList<String>();
		dataList4 = new ArrayList<String>();
		dataList8 = new ArrayList<String>();
		TABTag = new JTabbedPane();
		PanelOfficer = new JPanel();
		btnKeep = new JButton();
		btnDelete = new JButton();
		ShowJong = new JTextField();
		PanelShowQ = new JPanel();
		ShowQ2 = new JPanel();
		ShowQ2.setBorder(new TitledBorder("Show Queue Table:2"));
		ShowQ2.setLayout(new GridLayout(1, 10));
		ShowQ4 = new JPanel();
		ShowQ4.setBorder(new TitledBorder("Show Queue Table:4"));
		ShowQ8 = new JPanel();
		ShowQ4.setLayout(new GridLayout(1, 10));
		ShowQ8.setBorder(new TitledBorder("Show Queue Table:8"));
		ShowQ8.setLayout(new GridLayout(1, 10));
		QueueTab = new JPanel();
		IncreasrTab = new JPanel();
		ChangeTimeTab = new JPanel();

		PanelDelete = new JPanel();
		PanelDelete2 = new JPanel();
		btnConferm = new JButton();
		DeleateQ = new JTextField();
		DeleteQQLable = new JLabel();
		PleasePutLable = new JLabel();

		ManagerTab = new JPanel();
		ManagerTab.setLayout(new GridLayout(2, 1));
		ManagerTab.add(PanelOfficer, BorderLayout.WEST);
		ManagerTab.add(PanelShowQ, BorderLayout.EAST);
		PanelShowQ.setBorder(new TitledBorder(""));

		// in PanelOfficer
		Phone = new JLabel();
		Number = new JLabel();
		Amount = new JLabel();
		InputAmount = new JTextField(3);
		InputPhone = new JTextField(11);
		Amount.setFont(new Font("Tahoma", 3, 18));
		Amount.setForeground(new Color(0, 0, 0));
		Amount.setText("Amount");

		Phone.setFont(new Font("Tahoma", 3, 18));
		Phone.setForeground(new Color(0, 0, 0));
		Phone.setText("Phone");

		Number.setFont(new Font("Tahoma", 3, 18));
		Number.setForeground(new Color(0, 0, 0));
		Number.setText("Number");

		InputPhone.setFont(new Font("Tahoma", 3, 18));
		InputPhone.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				inAmount = 0;
				inPhone = 1;
			}
		});
		InputAmount.setFont(new Font("Tahoma", 3, 18));
		InputAmount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				inAmount = 1;
				inPhone = 0;
			}
		});
		InputAmount.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				inAmount = 1;
				inPhone = 0;
			}
		});
		PanelOfficer.setLayout(new GridLayout(0, 4));

		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout(0, 1));
		JPanel jp1 = new JPanel();

		jp.add(Amount);
		jp.add(InputAmount);
		jp.add(Phone);
		jp.add(Number);
		jp.add(InputPhone);
		// jp.setBorder(new TitledBorder("Please Key data"));
		// jp.setBackground(Color.WHITE);
		jp1.add(jp);

		// *****
		JPanel jpIn = new JPanel();
		jpIn.setLayout(new GridLayout(0, 2));
		JPanel jpStatus = new JPanel();
		// Status
		JLabel T2 = new JLabel("<html>" + "<br>" + " Empty " + "<html>"); // changeStatus
		JLabel T4 = new JLabel("<html>" + "<br>" + " Empty " + "<html>");
		JLabel T8 = new JLabel("<html>" + "<br>" + " Empty " + "<html>");
		JLabel ShowTable2 = new JLabel("<html>" + "<br>" + "Status Table 2:  " + "<html>");
		JLabel ShowTable4 = new JLabel("<html>" + "<br>" + "Status Table 4:  " + "<html>");
		JLabel ShowTable8 = new JLabel("<html>" + "<br>" + "Status Table 8:  " + "<html>");
		ShowTable2.setFont(new Font("Tahoma", 3, 18));
		ShowTable4.setFont(new Font("Tahoma", 3, 18));
		ShowTable8.setFont(new Font("Tahoma", 3, 18));
		T2.setFont(new Font("Tahoma", 3, 18));
		T4.setFont(new Font("Tahoma", 3, 18));
		T8.setFont(new Font("Tahoma", 3, 18));
		T2.setForeground(new Color(3, 255, 41));
		T4.setForeground(new Color(3, 255, 41));
		T8.setForeground(new Color(3, 255, 41));
		jpIn.setLayout(new GridLayout(3, 2));
		jpIn.add(ShowTable2);
		jpIn.add(T2);
		jpIn.add(ShowTable4);
		jpIn.add(T4);
		jpIn.add(ShowTable8);
		jpIn.add(T8);
		jpStatus.add(jpIn, BorderLayout.CENTER);
		PanelOfficer.add(jpStatus);
		JPanel jp0 = new JPanel();
		jp0.setLayout(new GridLayout(2, 0));
		jp0.add(jp1);

		JPanel jp3 = new JPanel();// add number
		JButton btn2 = new JButton("*");
		JButton btn3 = new JButton("#");
		jp3.setLayout(new GridLayout(4, 3, 20, -7));// ��Ҵ���ź����˭�
		this.btn = new JButton[10];
		for (int i = 0; i < 10; i++) {
			btn[i] = new JButton("" + i);
			btn[i].setFont(new Font("Tahoma", 1, 16));
			btn[i].setActionCommand("" + i);
			btn[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for (int i = 0; i < 10; i++) {
						if (inAmount == 1 && e.getActionCommand().equals("" + i)) {
							InputAmount.setText(InputAmount.getText() + i);

						} else if (inPhone == 1 && e.getActionCommand().equals("" + i)) {
							InputPhone.setText(InputPhone.getText() + i);

						}
					}
				}
			});
			if (i > 0) {
				jp3.add(btn[i]);
			}
			jp3.add(btn2);
			jp3.add(btn[0]);
			jp3.add(btn3);
		}
		JPanel x = new JPanel();
		x.setLayout(new GridLayout(2, 0));
		JPanel xx = new JPanel();
		x.add(jp3);
		jp0.add(x);
		PanelOfficer.add(jp0);
		// All Button
		JPanel KeepAndDeleate = new JPanel();

		////////////////////////////////////////////////////////////////////////////////
		ShowQ2.setBackground(new Color(255, 204, 204));
		ShowQ2.setLayout(new GridLayout(0, 7));
		ShowQ4.setBackground(new Color(255, 255, 204));
		ShowQ2.setLayout(new GridLayout(0, 7));
		ShowQ8.setBackground(new Color(204, 255, 204));
		ShowQ2.setLayout(new GridLayout(0, 7));

		PanelShowQ.setLayout(new GridLayout(3, 0));
		PanelShowQ.add(ShowQ2);
		PanelShowQ.add(ShowQ4);
		PanelShowQ.add(ShowQ8);

		////////////////////////////////////////////////////////////////////////////////////////////////////////////
		btnKeep.setFont(new Font("Tahoma", 1, 18));
		queueOutStore = new ShowQueueOut();
		btnKeep.setText("KEEP");
		btnKeep.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {// --------->keep bottom
				try {
					amount = Integer.valueOf(InputAmount.getText());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(null, "Please enter  integer!");
				}

				phone = InputPhone.getText();

				Person personTmp;
				int q;
				//////////////////// DQ/////////////////
				// IDtable IDtb = new IDtable();
				// showQTdai = new JLabel(" 0");// Set Show**Action
				// +++++++++++++++++++++++space5
				showQTdai.setFont(new Font("Tahoma", 1, 100));
				gg.setBorder(new TitledBorder("YOU GET TABLE ID:"));
				gg.setLayout(new GridLayout(2, 0));
				// **Delete Q
				// IDtb.setIDtable();
				inCreat.mg.setIDtable();
				if (amount <= 2) {// ------------------>> two table
					try {
						personTmp = new Person("Two", queue, amount, phone, halfHour, email);
						personTmp.insertIntoDatabase();
						String SetName = personTmp.getIdQueue() + "#" + ":" + personTmp.getPhoneNumber();
						dataList2.add(SetName);
						checkQueue++;
						ShowQ2.add(iDNumber1);

						customerOut2.enQueue(personTmp);
						
						RT.zoneA[QQ2].setText("#" + personTmp.getIdQueue());
						RT.timezoneA[QQ2].setText(""+personTmp.getTime());

						if (inCreat.mg.keepNum - inCreat.mg.use2 > 0) {
							showQTdai.setText("    " + inCreat.mg.setuse2(set2) + "A");
							dataList2.remove(q2);
							customer.DeleteData(personTmp.getIdQueue());
							//Queue qqq = new Queue();

							//RT.zoneA[QQ2].setText("#" + personTmp.getIdQueue());
							// RT.timezoneA[QQ2].setText(""+qqq.inQ(QQ2).getTime());
							//RT.timezoneA[QQ2].setText("" + personTmp.getTime());
							

							QQ2++;
						} else {
							iDNumber1.setText(dataList2.toString());
							queueOutStore.l1[q2 + 1].setText(dataList2.get(q2).toString());
							T2.setText("<html>" + "<br>" + " FULL " + "<html>");
							T2.setForeground(Color.RED);

							//// Settime /////

							// sqi.SetTable2(("#"+personTmp.getIdQueue()), QQ2);
							// //Set sitdown table
							// QQ2++;

							if (email != null) {
								SendMail se = new SendMail("" + personTmp.getIdQueue(), email);

							}
							q2++;

						}
						// set2++;
						validate();
						customer.enQueue(personTmp);
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}

				} else if (amount <= 4) {// ------------->> four table
					try {
						personTmp = new Person("Four", queue, amount, phone, halfHour, email);
						personTmp.insertIntoDatabase();
						String SetName = personTmp.getIdQueue() + "#" + ":" + personTmp.getPhoneNumber();
						dataList4.add(SetName);
						checkQueue++;
						ShowQ4.add(iDNumber2);

						customerOut4.enQueue(personTmp);
						RT.zoneB[QQ4].setText("#" + personTmp.getIdQueue());
						RT.timezoneB[QQ4].setText(""+personTmp.getTime());
						QQ4++;
						if (inCreat.mg.keepNum2 - inCreat.mg.use4 > 0) {
							showQTdai.setText("    " + inCreat.mg.setuse4(set4) + "B");
							dataList4.remove(q4);
							customer.DeleteData(personTmp.getIdQueue());
							

						} else {
							iDNumber2.setText(dataList4.toString());
							queueOutStore.l2[q4 + 1].setText(dataList4.get(q4).toString());
							T4.setText("<html>" + "<br>" + " FULL " + "<html>");
							T4.setForeground(Color.RED);
							if (email != null) {
								SendMail se = new SendMail("" + personTmp.getIdQueue(), email);

							}
							q4++;

						}
						// set4++;
						validate();
						customer.enQueue(personTmp);
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}

				} else if (amount > 4) {// ------------->> eight table
					try {
						personTmp = new Person("Eight", queue, amount, phone, halfHour, email);
						personTmp.insertIntoDatabase();
						String SetName = personTmp.getIdQueue() + "#" + ":" + personTmp.getPhoneNumber();
						dataList8.add(SetName);
						checkQueue++;
						ShowQ8.add(iDNumber3);

						customerOut8.enQueue(personTmp);

						RT.zoneC[QQ8].setText("#" + personTmp.getIdQueue());
						RT.timezoneC[QQ8].setText(""+personTmp.getTime());
						QQ8++;
						if (inCreat.mg.keepNum3 - inCreat.mg.use8 > 0) {
							showQTdai.setText("    " + inCreat.mg.setuse8(set8) + "C");
							dataList8.remove(q8);
							customer.DeleteData(personTmp.getIdQueue());

						

						} else {
							
							iDNumber3.setText(dataList8.toString());
							queueOutStore.l3[q8 + 1].setText(dataList8.get(q8).toString());
							if (email != null) {
								SendMail se = new SendMail("" + personTmp.getIdQueue(), email);

							}
							T8.setText("<html>" + "<br>" + " FULL " + "<html>");
							T8.setForeground(Color.RED);
							q8++;

						}
						// set8++;
						validate();
						revalidate();
						customer.enQueue(personTmp);
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}

				}
				tmptime = customer.queueSize();
				revalidate();
				validate();
				if(QQ2 >= 6){
					
				}
				queue++;
				super.mousePressed(arg0);
			}
		});
		//////////////////////////////////////////////////////////////////////////////////////

		btnDelete.setFont(new Font("Tahoma", 1, 18));
		btnDelete.setText("DELETE INPUT");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				if (inAmount == 1) {// ------------------------------>>clear_txt_box
									// bottom
					InputAmount.setText("");
				} else if (inPhone == 1) {
					InputPhone.setText("");

				} else {

				}
			}
		});
		/////////////////////////////////////////////////////////////////////////////////////

		addMail = new JButton("<html>" + "@Your E-Mail" + "<br>" + "<html>" + "Please Click");
		addMail.setFont(new Font("Tahoma", 1, 16));
		KeepAndDeleate.setLayout(new GridLayout(3, 0));
		KeepAndDeleate.add(btnKeep);
		KeepAndDeleate.add(btnDelete);
		KeepAndDeleate.add(addMail);
		addMail.addActionListener(new ActionListener() {// ------------->>Add_mail_Bottom
			public void actionPerformed(ActionEvent evt) {
				email = JOptionPane.showInputDialog(null, null, email).toString();
				// System.out.println(email);// Ezez

			}
		});
		////////////////////////////////////////////////////////////////////////////

		JPanel inlock = new JPanel();
		inlock.add(KeepAndDeleate);
		PanelOfficer.add(inlock);

		////////////////////////////////////////////////////////////////////////////

		btnConferm.setFont(new java.awt.Font("Tahoma", 1, 14));
		btnConferm.setText("CONFERM");
		btnConferm.addMouseListener(new MouseAdapter() {// ----->>conform_delete_���˹����ҹ
			@Override
			public void mousePressed(MouseEvent arg0) {
				int delete = Integer.valueOf(DeleateQ.getText());
				String s = DeleateQ.getText();
				customer.DeleteData(delete);

				for (int i = 0; i < dataList2.size(); i++) {
					if (dataList2.get(i).lastIndexOf(s, 3) == 0) {
						dataList2.remove(i);
						iDNumber1.setText(dataList2.toString());
						q2--;
						int j;
						for (j = 0; j < dataList2.size(); j++) {
							queueOutStore.l1[j + 1].setText(dataList2.get(j).toString());

						}
						queueOutStore.l1[j + 1].setText("");

					}

				}
				for (int i = 0; i < dataList4.size(); i++) {
					if (dataList4.get(i).lastIndexOf(s, 3) == 0) {
						dataList4.remove(i);
						iDNumber2.setText(dataList4.toString());
						q4--;
						int j;
						for (j = 0; j < dataList4.size(); j++) {
							queueOutStore.l2[j + 1].setText(dataList4.get(j).toString());

						}
						queueOutStore.l2[j + 1].setText("");
					}

				}
				for (int i = 0; i < dataList8.size(); i++) {
					if (dataList8.get(i).lastIndexOf(s, 3) == 0) {
						dataList8.remove(i);
						iDNumber3.setText(dataList8.toString());
						q8--;
						int j;
						for (j = 0; j < dataList8.size(); j++) {
							queueOutStore.l3[j + 1].setText(dataList8.get(j).toString());

						}
						queueOutStore.l3[j + 1].setText("");
					}

				}
				for (int i = 0; i < customer.queueSize(); i++) {
					if (customer.inQ(i).getIdQueue() == delete) {
						customer.remove(customer.inQ(i));// Delete database

						// iDNumber.setText(dataList.toString());//Delete showQ
						// checkQueue++;
						// ShowQ4.add(iDNumber);
						// dataList.add(SetName);
						// iDNumber3.setText(dataList.toString());
						// checkQueue++;
						// ShowQ8.add(iDNumber3);
						// customer.enQueue(personTmp);

					}
				}
				validate();
				repaint();
				super.mousePressed(arg0);
			}
		});

		////////////////////////////////////////////////////////////////////////////

		DeleteQQLable.setBackground(new java.awt.Color(0, 0, 0));
		DeleteQQLable.setFont(new java.awt.Font("Tekton Pro", 3, 16));
		DeleteQQLable.setText("DELETE QUEUE");
		PleasePutLable.setFont(new java.awt.Font("Tahoma", 1, 10));
		PleasePutLable.setText("Please Put Number of Queue");
		PanelDelete.setLayout(new GridLayout(0, 2));
		PanelDelete2.setLayout(new GridLayout(2, 1));
		JPanel jxx = new JPanel();
		JPanel jxx1 = new JPanel();
		JPanel jxx2 = new JPanel();
		PanelDelete2.add(DeleteQQLable);
		PanelDelete.add(jxx1);
		PanelDelete.add(jxx2);
		PanelDelete2.add(PleasePutLable);
		PanelDelete.add(PanelDelete2);
		PanelDelete.add(DeleateQ);
		PanelDelete.add(jxx);
		PanelDelete.add(btnConferm);
		gg.add(showQTdai, BorderLayout.CENTER);
		JPanel jx = new JPanel();
		jx.add(PanelDelete);
		gg.add(jx);
		PanelOfficer.add(gg);
		////////////////////////////////////////////////////////////////////////////

		// --------------------------------->>TABTime

		TABTag.add(ManagerTab, "#Manager");
		TABTag.add(QueueTab, "#Queue in Store");
		TABTag.add(IncreasrTab, "#Increasr Table");
		TABTag.add(ChangeTimeTab, "#Change time");
		// **************** P2

		// ----------------------------------------->>@tab
		// AddTable inCreat = new AddTable();
		// inCreat.ok.addActionListener(new ActionListener() {
		// public void actionPerformed(ActionEvent evt) {
		// ShowQueueInVer2 sqi = new ShowQueueInVer2(inCreat.mg.tmg.max2,
		// inCreat.mg.tmg.max4, inCreat.mg.tmg.max8);
		// QueueTab.removeAll();
		// QueueTab.add(sqi.getgPanel());
		// validate();
		//
		//
		// }
		// });
		DeleteQueue DQ = new DeleteQueue();
		DQ.btnDelete.addActionListener(new ActionListener() {// ------------->>Add_mail_Bottom
			public void actionPerformed(ActionEvent evt) {

			}
		});
		JPanel jpDQ = new JPanel();//////////// DQ
		jpDQ.setLayout(new GridLayout(2, 0));
		JPanel jpDQ1 = new JPanel();
		jpDQ1.setBackground(Color.GRAY);
		JPanel jpDQ2 = new JPanel();
		jpDQ2.setBackground(Color.DARK_GRAY);
		jpDQ.add(DQ.getPanelDQ());
		jpDQ.add(jpDQ1);
		inCreat.ok.addActionListener(new ActionListener() {// ------------->>Add_mail_Bottom
			public void actionPerformed(ActionEvent evt) {
				if (inCreat.two.isSelected()) {
					int x;
					x = Integer.valueOf(inCreat.amount.getText());
					inCreat.mg.tmg.max2 += x;
					inCreat.mg.two += x;
					inCreat.mg.all += x;
					// inCreat.mg.keepNum+=x;
					// inCreat.mg.keepNum2+=x;
					// inCreat.mg.keepNum3+=x;

					// mg.addTable(2);
					// System.out.println(mg.two);
					// System.out.println(mg.tmg.WarningT2());

				} else if (inCreat.four.isSelected()) {
					int x;
					x = Integer.valueOf(inCreat.amount.getText());
					inCreat.mg.tmg.max4 += x;
					inCreat.mg.four += x;

					inCreat.mg.all += x;
					// inCreat.mg.keepNum2+=x;
					// inCreat.mg.keepNum3+=x;
					// System.out.println(mg.four);

				} else if (inCreat.eight.isSelected()) {
					int x;
					x = Integer.valueOf(inCreat.amount.getText());
					inCreat.mg.tmg.max8 += x;
					inCreat.mg.eight += x;

					inCreat.mg.all += x;
					// inCreat.mg.keepNum3+=x;
					// System.out.println(mg.eight);

				}
				inCreat.mg.setIDtable();

			}
		});
		inCreat.ok.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				ShowQueueInVer2 sqi = new ShowQueueInVer2(inCreat.mg.tmg.max2, inCreat.mg.tmg.max4,
						inCreat.mg.tmg.max8);
				QueueTab.removeAll();
				QueueTab.add(sqi.getgPanel());
				QueueTab.add(jpDQ);

				inCreat.mg.setIDtable();
				System.out.println(inCreat.mg.tmg.max2 + "  " + inCreat.mg.tmg.max4 + "  " + inCreat.mg.tmg.max8 + "\n"
						+ inCreat.mg.use2 + "  " + inCreat.mg.use4 + "  " + inCreat.mg.use8 + "\n" + inCreat.mg.keepNum
						+ "  " + inCreat.mg.keepNum2 + "  " + inCreat.mg.keepNum3);
				validate();
				super.mouseClicked(arg0);
			}
		});
		ShowQueueInVer2 sqi = new ShowQueueInVer2(inCreat.mg.tmg.max2, inCreat.mg.tmg.max4, inCreat.mg.tmg.max8);
		QueueTab.add(sqi.getgPanel());
		QueueTab.setLayout(new GridLayout(0, 2));
		QueueTab.add(jpDQ);

		// IncreasrTab // tab3
		JPanel All = new JPanel();
		JPanel jpxx1 = new JPanel();
		JPanel jpxx2 = new JPanel();
		All.add(inCreat.pAll);

		IncreasrTab.setLayout(new GridLayout(3, 0));
		IncreasrTab.add(jpxx1);
		jpxx1.setBackground(Color.DARK_GRAY);
		IncreasrTab.add(All);
		All.setBorder(new TitledBorder(""));
		IncreasrTab.add(jpxx2);
		jpxx2.setBackground(Color.GRAY);

		////////////////////////////////////////////////////////////////////////////

		AddTime addTime = new AddTime();// ---------->>ChangeTimeTab;// tab4
		JPanel All1 = new JPanel();
		JPanel jpxx3 = new JPanel();
		JPanel jpxx4 = new JPanel();
		All1.add(addTime.pAll);
		addTime.ok.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int timee=Integer.valueOf(addTime.textTime.getText());
				halfHour=timee;
				validate();
				super.mouseClicked(arg0);
			}
		});
		ChangeTimeTab.setLayout(new GridLayout(3, 0));
		ChangeTimeTab.add(jpxx3);
		jpxx3.setBackground(Color.DARK_GRAY);
		ChangeTimeTab.add(All1);
		All.setBorder(new TitledBorder(""));
		ChangeTimeTab.add(jpxx4);
		jpxx4.setBackground(Color.GRAY);

		////////////////////////////////////////////////////////////////////////////
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File("open.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image dimg = img.getScaledInstance(1000, 600, Image.SCALE_SMOOTH);
		ImageIcon imageIcon = new ImageIcon(dimg);
		JLabel openpic = new JLabel() {
			public void paintComponent(Graphics g) {
				g.drawImage(imageIcon.getImage(), 0, 0, null);
				super.paintComponent(g);
			}
		};
		add(openpic, BorderLayout.CENTER);
		openpic.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				remove(openpic);
				add(TABTag);
				validate();
			}
		});
		/////////////////////////////////////////////
		add(openpic);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		// add(TABTag);
		setExtendedState(MAXIMIZED_BOTH);
		setSize(1000, 600);
		setVisible(true);
	}

	public void addShowQ2Panel() {
		JLabel[] label = new JLabel[10];
		for (int i = 0; i < 10; i++) {
			label[i] = new JLabel();
			label[i].setSize(50, 50);
			label[i].setText(customer.inQ(i).getIdQueue() + "\t" + customer.inQ(i).getPhoneNumber());
			ShowQ2.add(label[i]);
			validate();

		}

	}

	private void setRT() {

		if (!customerOut2.isEmpty()) {
			try {
				if (!customerIn2.isEmpty()) {
					customerIn2.frontQ().setTime(customerIn2.frontQ().getTime() - 1);
					T2.setText("<html>" + "<br>" + " EMPTY " + "<html>");
					T2.setForeground(Color.GREEN);
					if(QQ2>6){
						QQ2 = 6;
					}
				}

				if ((customerIn2.frontQ().getTime() == 0 || !customerIn2.isEmpty()) && customerIn2.queueSize() <= 5) {

					customerIn2.deQueue();
					customerIn2.enQueue(customerOut2.deQueue());
					QQ2--;
					System.out.println("tic tic");

					for (int i = 0; i < customerIn2.queueSize(); i++) {
						RT.zoneA[i].setText("# " + customerIn2.inQ(i).getIdQueue());
						RT.timezoneA[i].setText("# " + customerIn2.inQ(i).getTime());
					}
					

				}
			} catch (EmptyQException e1) {
				for (int i = 1; i <= 5; i++) {
					RT.zoneA[i].setText("--");
					RT.timezoneA[i].setText("00");
				}
				System.out.println("Q2 " + e1.getMessage());
			}

			if (!customerOut4.isEmpty()) {
				try {
					if (!customerIn4.isEmpty()) {
						customerIn4.frontQ().setTime(customerIn4.frontQ().getTime() - 1);
					}
					
					if ((customerIn4.frontQ().getTime() == 0 || !customerIn4.isEmpty())
							&& customerIn4.queueSize() <= 5) {

						customerIn4.deQueue();
						customerIn4.enQueue(customerOut4.deQueue());

						System.out.println("tic tic");

						for (int i = 0; i < customerIn4.queueSize(); i++) {
							RT.zoneB[i].setText("# " + customerIn4.inQ(i).getIdQueue());
							RT.timezoneB[i].setText("# " + customerIn4.inQ(i).getTime());
						}

					}
				} catch (EmptyQException e1) {
					System.out.println("Q4 " + e1.getMessage());

				}
			}
			if (!customerOut8.isEmpty()) {
				try {
					if(!customerIn8.isEmpty()){
					customerIn8.frontQ().setTime(customerIn8.frontQ().getTime() - 1);
					}
					if ((customerIn8.frontQ().getTime() == 0 || !customerIn8.isEmpty())
							&& customerIn8.queueSize() <= 5) {

						customerIn8.deQueue();
						customerIn8.enQueue(customerOut8.deQueue());

						System.out.println("tic tic");

						for (int i = 0; i < customerIn8.queueSize(); i++) {
							RT.zoneC[i].setText("# " + customerIn8.inQ(i).getIdQueue());
							RT.timezoneC[i].setText("# " + customerIn8.inQ(i).getTime());
						}

					}
				} catch (EmptyQException e1) {
					System.out.println("Q8 " + e1.getMessage());
				}
			}

		}

		this.revalidate();
		this.validate();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		setRT();
		revalidate();
	}

}
