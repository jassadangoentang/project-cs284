
import javax.mail.*;

	class SMTPAuthenticator extends javax.mail.Authenticator {

		private String account;
private String password;
	
public SMTPAuthenticator(String acc,String pwd){
account = acc;
password = pwd;
}

public PasswordAuthentication getPasswordAuthentication() {
return new PasswordAuthentication(account, password);
}
}