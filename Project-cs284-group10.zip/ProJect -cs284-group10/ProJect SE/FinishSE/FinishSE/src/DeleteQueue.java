import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.net.*;
import java.io.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class DeleteQueue extends JPanel {
	private JLabel dQueue;
	private JLabel lPut;
	private JTextField txt;
	public JButton btnDelete;
	private ImageIcon pic;
	private JPanel panel,panelZ;
	
	public DeleteQueue(){
		pic = new ImageIcon("dq.jpg");
		lPut = new JLabel("Put the number of queues.");
		lPut.setFont(new java.awt.Font("Tekton Pro", 3, 20));
		lPut.setForeground(Color.WHITE);
		txt = new JTextField(10);
		btnDelete = new JButton("Delete");
		
		String text = "DELETE QUEUE";
		dQueue = new JLabel("DELETE QUEUE", SwingConstants.CENTER){
			public void paintComponent(Graphics g) {
				Dimension size = dQueue.getSize();
                Image im = pic.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
		        g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
		        super.paintComponent(g);
		      }
		};
		dQueue.setFont(new java.awt.Font("Tekton Pro", 3, 25));
		dQueue.setForeground(Color.WHITE);

		
		
		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		JPanel pPut = new JPanel();
		pPut.setLayout(new FlowLayout());
		pPut.setBackground(Color.BLACK);
		pPut.add(lPut);
		JPanel pTxt = new JPanel();
		pTxt.setBackground(Color.BLACK);
		pTxt.add(txt);
		JPanel pBtn = new JPanel();
		pBtn.setBackground(Color.BLACK);
		pBtn.add(btnDelete);
		
		panel.setLayout(new GridLayout(3,0));
		panel.add(pPut);
		panel.add(pTxt);
		panel.add(pBtn);
		this.add(panel);
		
		panelZ = new JPanel();
		panelZ.setLayout(new GridLayout(2,0));
		panelZ.add(dQueue);
		panelZ.add(panel);
	
	}
	public JPanel getPanelDQ(){
		return panelZ;
	}
//	public static void main(String[] arg){
//		JFrame frame = new JFrame();
//		frame.add(new DeleteQueue());
//		
//		frame.pack();
//		frame.setVisible(true);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//	}


}
