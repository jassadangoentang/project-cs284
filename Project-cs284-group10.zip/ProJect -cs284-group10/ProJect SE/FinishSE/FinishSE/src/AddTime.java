import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AddTime extends JPanel implements ActionListener{
	private JPanel northPanel, southPanel; // ���ź�,������ҧ
	private JLabel title,id,add,minute;
	public JButton ok;
	public JTextField textId,textTime;
	public  JPanel p1, p2, p3,pAll; // ���ŷ�������southPanel
	public AddTime() {
		pAll= new JPanel();
		BorderLayout bigPanel = new BorderLayout();
		this.setLayout(bigPanel);
		northPanel = new JPanel();
		northPanel.setBorder(BorderFactory.createTitledBorder(""));
		northPanel.setPreferredSize(new Dimension(400, 80));
		northPanel.setBackground(Color.darkGray);

		title = new JLabel("ADD TIME");
		title.setFont(new Font("Tahoma", Font.BOLD, 40));
		title.setForeground(Color.WHITE);
		northPanel.add(title);
		
		
		
		southPanel = new JPanel();
		southPanel.setBorder(BorderFactory.createTitledBorder(""));
		southPanel.setPreferredSize(new Dimension(400, 80));
		southPanel.setLayout(new GridLayout(3, 0));
		
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		
		id = new JLabel("ID Table ");
		id.setFont(new Font("Tahoma", Font.BOLD, 15));
		id.setForeground(Color.WHITE);
		
		add = new JLabel("Add Time ");
		add.setFont(new Font("Tahoma", Font.BOLD, 15));
		add.setForeground(Color.WHITE);
		
		minute = new JLabel("Minute");
		minute.setFont(new Font("Tahoma", Font.BOLD, 15));
		minute.setForeground(Color.WHITE);
		
		textId = new JTextField(13);
		textTime = new JTextField(10);
		
		ok = new JButton("OK");
		
		p1.add(id);
		p1.add(textId);
		
		p2.add(add);
		p2.add(textTime);
		p2.add(minute);
		
		p3.add(ok);
		
		p1.setBackground(Color.gray);
		p2.setBackground(Color.gray);
		p3.setBackground(Color.gray);
		southPanel.add(p1);
		southPanel.add(p2);
		southPanel.add(p3);
		
		pAll.setLayout(new GridLayout(2,0));
		pAll.add(northPanel);
		pAll.add(southPanel);
//		this.add(northPanel,BorderLayout.NORTH);
//		this.add(southPanel);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
//	public static void main(String[] args) {
//		JFrame frame = new JFrame();
//		AddTime adTime = new AddTime();
//		frame.setSize(400, 220);
//		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
//		frame.setVisible(true);
//		frame.add(adTime);
//
//	}

}
