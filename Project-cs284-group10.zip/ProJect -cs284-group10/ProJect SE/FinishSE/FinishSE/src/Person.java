import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Person {
	private int idQueue, amount;
	private String idTable;
	private String email;
	private String phoneNumber;
	private int time;

	public Person(String idTable, int idQueue, int amount, String phoneNumber,int time, String eMail) {
		this.idTable = idTable;
		this.idQueue = idQueue;
		this.phoneNumber = phoneNumber;
		this.email = eMail;
		this.amount = amount;
		this.time = time;
	}

	public Person(int idQueue, int amount, String phoneNumber, String eMail) {
		this.idQueue = idQueue;
		this.amount = amount;
		this.phoneNumber = phoneNumber;
		this.email = eMail;
		DBConnection dbConn = new DBConnection();
		dbConn.openConnection();

		System.out.println("Connection Success");

		String sqlcommand = "SELECT \"idQueue\", \"Amount\", phone, email FROM \"Data\" ";
		idQueue++;

		String sqll = "INSERT INTO \"Data\"(\"idQueue\", \"Amount\", phone, email)VALUES ('" + idQueue + "', '" + amount
				+ "', '" + phoneNumber + "', '" + email + "');";

		try {
			Connection cc = dbConn.openConnection2();
			Statement stm = cc.createStatement();
			stm.execute(sqll);
			
		} catch (SQLException ex) {
			System.out.println("error");

		}

	}
	public void insertIntoDatabase() {
		DBConnection dbConn = new DBConnection();
		dbConn.openConnection();

		System.out.println("Connection Success");

		String sqlcommand = "SELECT \"idQueue\", \"Amount\", phone, email FROM \"Data\" ";
		
		String sqll = "INSERT INTO \"Data\"(\"idQueue\", \"Amount\", phone, email)VALUES ('" + idQueue + "', '" + amount
				+ "', '" + phoneNumber + "', '" + email + "');";

		try {
			Connection cc = dbConn.openConnection2();
			Statement stm = cc.createStatement();
			stm.execute(sqll);
			System.out.println("in");
		} catch (SQLException ex) {
			System.out.println("error");

		}

	}
	public void DeleteDatabase() {
		DBConnection dbConn = new DBConnection();
		dbConn.openConnection();

		System.out.println("Connection Success");
		
		String sqlcommand = "SELECT \"idQueue\", \"Amount\", phone, email FROM \"Data\" ";
		
		String sqll = "DELETE FROM \"Data\" WHERE \"idQueue\"= "+idQueue+";";

		try {
			Connection cc = dbConn.openConnection2();
			Statement stm = cc.createStatement();
			stm.execute(sqll);
			System.out.println("out");
		} catch (SQLException ex) {
			System.out.println("error");

		}

	}

	public void setTime(int time) {
		this.time = time;
	}
	public int getTime() {
		return time;
	}
	public String getIdTable() {
		return idTable;
	}
	public void setIdQueue(int q){
		this.idQueue = q;
	}
	public int getIdQueue() {
		return idQueue;
	}

	public String geteMail() {
		return email;
	}

	public int getAmount() {
		return amount;
	}

	public void setName(String eMail) {
		this.email = eMail;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String toString() {
		return idTable + " " + idQueue + " " + phoneNumber + " " + email;

	}

}
