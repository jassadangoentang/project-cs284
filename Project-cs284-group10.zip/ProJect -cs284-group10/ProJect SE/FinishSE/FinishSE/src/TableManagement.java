import java.util.ArrayList;

public class TableManagement {

	private boolean hasTable2, hasTable4, hasTable8;
	private boolean fullTable2, fullTable4, fullTable8;
	public ArrayList<Integer> table2;
	public ArrayList<Integer> table4;
	public ArrayList<Integer> table8;
	public static int t2 = 0, t4 = 0, t8 = 0;
	public String Warning;
	public int max2, max4, max8;

	public TableManagement(int hast2, int hast4, int hast8, int maxtable) {
		this.max2 = hast2;
		this.max4 = hast4;
		this.max8 = hast8;
		this.table2 = new ArrayList<Integer>(max2);
		this.table4 = new ArrayList<Integer>(max4);
		this.table8 = new ArrayList<Integer>(max8);
		// +1 because table use 1 only
	}
	public TableManagement() {
	
		table2 = new ArrayList<Integer>(max2);
		table4 = new ArrayList<Integer>(max4);
		table8 = new ArrayList<Integer>(max8);
		// +1 because table use 1 only
	}

	// �ͧ���
	public void JongTable(int x) {
		if (x <= 2) {
			table2.add(x);
			t2++;
			System.out.println("We check in Table 2 chair");
		} else if (x == 3 || x == 4) {
			table4.add(x);
			t4++;
			System.out.println("We check in Table 4 chair");
		} else {
			table8.add(x);
			t8++;
			System.out.println("We check in Table 8 chair");
		}
	}

	// �ѧ�����
	public boolean hasTable2() {
		if (t2 < max2) {
			hasTable2 = true;
			fullTable2 = false;
			return hasTable2;
		} else if (t2 == max2) {
			hasTable2 = false;
			fullTable2 = true;
			return hasTable2;
		} else {
			hasTable2 = false;
			fullTable2 = true;
			return hasTable2;
		}
	}

	public boolean hasTable4() {
		if (t2 < max4) {
			hasTable4 = true;
			fullTable4 = false;
			return hasTable4;
		} else if (t4 == max4) {
			hasTable4 = false;
			fullTable4 = true;
			return hasTable4;
		} else {
			hasTable4 = false;
			fullTable4 = true;
			return hasTable4;
		}
	}

	public boolean hasTable8() {
		if (t2 < max8) {
			hasTable8 = true;
			fullTable8 = false;
			return hasTable8;
		} else if (t8 == max8) {
			hasTable8 = false;
			fullTable8 = true;
			return hasTable8;
		} else {
			hasTable8 = false;
			fullTable8 = true;
			return hasTable8;
		}
	}

	public String WarningT2() {
		if (t2 < max2) {
			Warning = "TABLE 2 NOT FULL" + " USE: " + table2.size() + " Tables";
			return Warning;
		} else if (t2 == max2) {
			Warning = "TABLE 2 FULL";
			return Warning;
		} else {
			Warning = "TABLE 2 FULL";
			return Warning;
		}
	}

	public String WarningT4() {
		if (t4 < max4) {
			Warning = "TABLE 4 NOT FULL" + " USE: " + table4.size() + " Tables";
			return Warning;
		} else if (t4 == max4) {
			Warning = "TABLE 4 FULL";
			return Warning;
		} else {
			Warning = "TABLE 4 FULL";
			return Warning;
		}
	}

	public String WarningT8() {
		if (t8 < max8) {
			Warning = "TABLE 8 NOT FULL" + " USE: " + table8.size() + " Tables";
			return Warning;
		} else if (t8 == max8) {
			Warning = "TABLE 8 FULL";
			return Warning;
		} else {
			Warning = "TABLE 8 FULL";
			return Warning;
		}
	}

	public void setMax2(int x) {
		max2 = x;
	}

	public void setMax4(int x) {
		max4 = x;
	}

	public void setMax8(int x) {
		max8 = x;
	}
	public Boolean isFull(){
		return fullTable2;
		
	}
	public static void main(String args[]){
		TableManagement tt = new TableManagement(2,5,5,15);
		System.out.println(tt.hasTable2());
		System.out.println(tt.hasTable4());
		System.out.println(tt.hasTable8());
		System.out.println( tt.WarningT2());
		tt.JongTable(2);
		System.out.println( tt.WarningT2());

		
	}
}
