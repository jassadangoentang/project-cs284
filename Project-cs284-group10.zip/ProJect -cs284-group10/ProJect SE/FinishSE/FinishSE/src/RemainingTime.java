import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class RemainingTime extends JFrame {
	private JPanel[] mainPanel;
	private int cMax = 0;
	private int table2;
	private int table4;
	private int table8;
	private ImageIcon pic;
	private ImageIcon pic2;
	private ImageIcon pic3;
	private JLabel remainT;
	public JLabel[] zoneA;
	public JLabel[] timezoneA;
	public JLabel[] zoneB;
	public JLabel[] timezoneB;
	public JLabel[] zoneC;
	public JLabel[] timezoneC;
	private int numTableA = 1;
	private int numTableB = 1;
	private int numTableC = 1;

	public RemainingTime(int q2, int q4, int q8) {
		table2 = q2;
		table4 = q4;
		table8 = q8;
		int[] m = { table2, table4, table8 };
		for (int i = 0; i < 3; i++) {
			if (m[i] > cMax) {
				cMax = m[i];
			}
		}
		cMax = cMax + 1;
		// ---------------------------------
		// ------Panel--Pic---
		pic = new ImageIcon("rt.jpg");
		pic2 = new ImageIcon("star.jpg");
		pic3 = new ImageIcon("Blue1.jpg");
		mainPanel = new JPanel[cMax + 1];
		remainT = new JLabel("Remaining Time", SwingConstants.CENTER) {
			public void paintComponent(Graphics g) {
				Dimension size = remainT.getSize();
				Image im = pic.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
				g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
				super.paintComponent(g);
			}
		};
		remainT.setFont(new java.awt.Font("Tekton Pro", 3, 25));
		remainT.setForeground(Color.WHITE);

		// --------------------------------------
		zoneA = new JLabel[6];
		zoneB = new JLabel[6];
		zoneC = new JLabel[6];
		timezoneA = new JLabel[6];
		timezoneB = new JLabel[6];
		timezoneC = new JLabel[6];
		// -Panel Time
		for (int i = 0; i < cMax; i++) {
			if (i == 0) {
				mainPanel[i] = new JPanel();
				mainPanel[i].setBackground(Color.BLACK);
				mainPanel[i].setLayout(new GridLayout(0, 6));
				// A
				zoneA[i] = new JLabel("Zone A", SwingConstants.CENTER) {
					public void paintComponent(Graphics g) {
						Dimension size = zoneA[0].getSize();
						Image im = pic2.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};
				zoneA[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
				zoneA[i].setForeground(Color.WHITE);
				mainPanel[i].add(zoneA[i]);
				timezoneA[i] = new JLabel("Timer", SwingConstants.CENTER);
				timezoneA[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
				timezoneA[i].setForeground(Color.WHITE);
				mainPanel[i].add(timezoneA[i]);
				// B
				zoneB[i] = new JLabel("Zone B", SwingConstants.CENTER) {
					public void paintComponent(Graphics g) {
						Dimension size = zoneB[0].getSize();
						Image im = pic2.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};
				zoneB[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
				zoneB[i].setForeground(Color.WHITE);
				mainPanel[i].add(zoneB[i]);
				timezoneB[i] = new JLabel("Timer", SwingConstants.CENTER);
				timezoneB[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
				timezoneB[i].setForeground(Color.WHITE);
				mainPanel[i].add(timezoneB[i]);
				// C
				zoneC[i] = new JLabel("Zone C", SwingConstants.CENTER) {
					public void paintComponent(Graphics g) {
						Dimension size = zoneC[0].getSize();
						Image im = pic2.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
						g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
						super.paintComponent(g);
					}
				};
				zoneC[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
				zoneC[i].setForeground(Color.WHITE);
				mainPanel[i].add(zoneC[i]);
				timezoneC[i] = new JLabel("Timer", SwingConstants.CENTER);
				timezoneC[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
				timezoneC[i].setForeground(Color.WHITE);
				mainPanel[i].add(timezoneC[i]);
			} else {
				mainPanel[i] = new JPanel();
				mainPanel[i].setBackground(Color.black);
				mainPanel[i].setLayout(new GridLayout(0, 6));
				// Zone AAAAAAAAAAAAAAAAAAA
				if (i <= table2) {
					zoneA[i] = new JLabel(numTableA + "A", SwingConstants.CENTER) {
						public void paintComponent(Graphics g) {
							Dimension size = zoneA[0].getSize();
							Image im = pic3.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
							g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
							super.paintComponent(g);
						}
					};
					zoneA[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					zoneA[i].setForeground(Color.WHITE);
					mainPanel[i].add(zoneA[i]);
					timezoneA[i] = new JLabel("set Time", SwingConstants.CENTER);
					timezoneA[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					timezoneA[i].setForeground(Color.WHITE);
					mainPanel[i].add(timezoneA[i]);
					numTableA++;
				} else if (i >= table2) {
					zoneA[i] = new JLabel() {
						public void paintComponent(Graphics g) {
							Dimension size = zoneA[0].getSize();
							Image im = pic3.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
							g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
							super.paintComponent(g);
						}
					};
					zoneA[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					zoneA[i].setForeground(Color.WHITE);
					mainPanel[i].add(zoneA[i]);
					timezoneA[i] = new JLabel("", SwingConstants.CENTER);
					timezoneA[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					timezoneA[i].setForeground(Color.WHITE);
					mainPanel[i].add(timezoneA[i]);
				}
				// Zone BBBBBBBBBBBBBBBBBBBBBBBBBBBB
				if (i <= table4) {
					zoneB[i] = new JLabel(numTableB + "B", SwingConstants.CENTER) {
						public void paintComponent(Graphics g) {
							Dimension size = zoneA[0].getSize();
							Image im = pic3.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
							g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
							super.paintComponent(g);
						}
					};
					zoneB[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					zoneB[i].setForeground(Color.WHITE);
					mainPanel[i].add(zoneB[i]);
					timezoneB[i] = new JLabel("set Time", SwingConstants.CENTER);
					timezoneB[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					timezoneB[i].setForeground(Color.WHITE);
					mainPanel[i].add(timezoneB[i]);
					numTableB++;
				} else if (i >= table4) {
					zoneB[i] = new JLabel() {
						public void paintComponent(Graphics g) {
							Dimension size = zoneB[0].getSize();
							Image im = pic3.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
							g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
							super.paintComponent(g);
						}
					};
					zoneB[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					zoneB[i].setForeground(Color.WHITE);
					mainPanel[i].add(zoneB[i]);
					timezoneB[i] = new JLabel("", SwingConstants.CENTER);
					timezoneB[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					timezoneB[i].setForeground(Color.WHITE);
					mainPanel[i].add(timezoneB[i]);
				}
				// Zone CCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
				if (i <= table8) {
					zoneC[i] = new JLabel(numTableC + "C", SwingConstants.CENTER) {
						public void paintComponent(Graphics g) {
							Dimension size = zoneA[0].getSize();
							Image im = pic3.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
							g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
							super.paintComponent(g);
						}
					};
					zoneC[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					zoneC[i].setForeground(Color.WHITE);
					mainPanel[i].add(zoneC[i]);
					timezoneC[i] = new JLabel("set Time", SwingConstants.CENTER);
					timezoneC[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					timezoneC[i].setForeground(Color.WHITE);
					mainPanel[i].add(timezoneC[i]);
					numTableC++;
				} else if (i >= table8) {
					zoneC[i] = new JLabel() {
						public void paintComponent(Graphics g) {
							Dimension size = zoneB[0].getSize();
							Image im = pic3.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
							g.drawImage((new ImageIcon(im).getImage()), 0, 0, null);
							super.paintComponent(g);
						}
					};
					zoneC[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					zoneC[i].setForeground(Color.WHITE);
					mainPanel[i].add(zoneC[i]);
					timezoneC[i] = new JLabel("", SwingConstants.CENTER);
					timezoneC[i].setFont(new java.awt.Font("Tekton Pro", 3, 20));
					timezoneC[i].setForeground(Color.WHITE);
					mainPanel[i].add(timezoneC[i]);
				}

				//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			}
		}

		setSize(800, 650);
		setTitle("Show Time");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridLayout(cMax + 2, 0));
		this.add(remainT);
		for (int i = 0; i < cMax; i++) {
			this.add(mainPanel[i]);
		}
		setBackground(Color.BLACK);
		setVisible(true);
	}
	

	//
	//
	//
	// public static void main(String[] arg){
	// JFrame frame = new JFrame();
	// frame.add(new RemainingTime(2 ,3 ,5));
	//
	// frame.pack();
	// frame.setVisible(true);
	// frame.setSize(500,500);
	// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// }

}
