
public class EmptyQException extends Exception {
	public EmptyQException(){
		super("Queue is empty!");
	}
}
