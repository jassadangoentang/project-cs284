import javax.swing.JPanel;

public class QinStore extends JPanel {
	private Queue[] qinStore;
	int numberOfTypeQ;

	public QinStore() {
		qinStore = new Queue[3];
		for (int i = 0; i < 3; i++) {
			qinStore[i] = new Queue();
		}
		numberOfTypeQ = 3;
	}

	public QinStore(int numberOfTypeQ) {
		this.numberOfTypeQ = numberOfTypeQ;
		qinStore = new Queue[numberOfTypeQ];
		for (int i = 0; i < 3; i++) {
			qinStore[i] = new Queue();
		}

	}

	public void addQ(Person p) {
		if (p.getIdTable().equalsIgnoreCase("A")) {
			qinStore[0].enQueue(p);
			;
		} else if (p.getIdTable().equalsIgnoreCase("B")) {
			qinStore[1].enQueue(p);
			;
		} else if (p.getIdTable().equalsIgnoreCase("C")) {
			qinStore[3].enQueue(p);
			;
		}
	}

	public static void main(String[] args) {

	}

}
