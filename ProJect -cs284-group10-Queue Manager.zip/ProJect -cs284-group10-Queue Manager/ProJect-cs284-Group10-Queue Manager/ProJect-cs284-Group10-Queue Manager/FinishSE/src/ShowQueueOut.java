import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ShowQueueOut extends JFrame {
	private JPanel kkk;
	private JPanel shopN;
	private JPanel gPanel;
	private JPanel p1;
	private JPanel p2;
	private JPanel p3;;
	public JLabel[] l1;
	public JLabel[] l2;
	public JLabel[] l3;
	private ImageIcon icon;
	private Queue queueClass ;
	private int a,b,c;
	private Controler contral;

	public ShowQueueOut() {
		queueClass = new Queue();
		kkk = new JPanel();
		icon = new ImageIcon("Set.jpg");
		//icon.getImage().getScaledInstance(getWidth(), getHeight(), Image.SCALE_DEFAULT);
		shopN = new JPanel();
		gPanel = new JPanel();
		
		p1 = new JPanel();
		p1.setLayout(new GridLayout(8, 0));
		l1 = new JLabel[4];
		p1.setBackground(Color.DARK_GRAY);

		p2 = new JPanel();
		p2.setLayout(new GridLayout(8, 0));
		l2 = new JLabel[4];
		p2.setBackground(Color.DARK_GRAY);

		p3 = new JPanel();
		p3.setLayout(new GridLayout(8, 0));
		l3 = new JLabel[4];
		p3.setBackground(Color.DARK_GRAY);
		
		l1 = new JLabel[7];
		l2 = new JLabel[7];
		l3 = new JLabel[7];
		//bg panel 1 ----------------------------------------------------
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File("Set.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	    Image dimg = img.getScaledInstance(250,100,Image.SCALE_SMOOTH);
	    ImageIcon imageIcon = new ImageIcon(dimg);
	    //----------------------------------------------------------------
	    //bg panel 2
	    BufferedImage img2 = null;
		try {
			img2 = ImageIO.read(new File("bg1.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	    Image dimg2 = img2.getScaledInstance(250,100,Image.SCALE_SMOOTH);
	    ImageIcon imageIcon2 = new ImageIcon(dimg2);
	    //-----------------------------------------------------------------
	    
	    
	    
	    for(int i = 0 ; i < 7; i++){ // p1
	    	if(i==0){
	    		l1[i] = new JLabel(){
	    			public void paintComponent(Graphics g) {
	    		        g.drawImage(imageIcon.getImage(), 0, 0, null);
	    		        super.paintComponent(g);
	    		      }
	    		};
	    		l1[i].setFont(new Font(l1[i].getName(), Font.PLAIN, 40));
    		    l1[i].setForeground(Color.WHITE);
    		    l1[i].setText("      "+ " Set A");
	    		p1.add(l1[i]);
	    	}else{
	    		//////////// Set Queue///////////
	    		l1[i]= new JLabel() {
	    		      public void paintComponent(Graphics g) {
	    		        g.drawImage(imageIcon2.getImage(), 0, 0, null);
	    		        super.paintComponent(g);
	    		      }
	    		    };

	    		    l1[i].setOpaque(false);
	    		    l1[i].setFont(new Font(l1[i].getName(), Font.PLAIN, 30));
	    		    l1[i].setForeground(Color.WHITE);
	    		   //l1[i].setText("   "+queueClass.getidQueue()+"#"+queueClass.getPhoneNumber());
	    		    getContentPane().add( l1[i] );
	    		    p1.add(l1[i]);
	    	}
	    }
	    

	    //------------------------------------------------------------------
	    for(int i = 0 ; i < 7; i++){ //p2
	    	if(i==0){
	    		l2[i] = new JLabel(){
	    			public void paintComponent(Graphics g) {
	    		        g.drawImage(imageIcon.getImage(), 0, 0, null);
	    		        super.paintComponent(g);
	    		      }
	    		};
	    		l2[i].setFont(new Font(l2[i].getName(), Font.PLAIN, 40));
    		    l2[i].setForeground(Color.WHITE);
    		    l2[i].setText("      "+ " Set B");
	    		p2.add(l2[i]);
	    	}else{
	    		l2[i]= new JLabel() {
	    		      public void paintComponent(Graphics g) {
	    		        g.drawImage(imageIcon2.getImage(), 0, 0, null);
	    		        super.paintComponent(g);
	    		      }
	    		    };

	    		    l2[i].setOpaque(false);
	    		    l2[i].setFont(new Font(l2[i].getName(), Font.PLAIN, 30));
	    		    l2[i].setForeground(Color.WHITE);
	    		//    l2[i].setText("          "+ " Guest");
	    		    getContentPane().add( l2[i] );
	    		    p2.add(l2[i]);
	    	}
	    }
	    //----------------------------------------------------------------
	    for(int i = 0 ; i < 7; i++){ //p2
	    	if(i==0){
	    		l3[i] = new JLabel(){
	    			public void paintComponent(Graphics g) {
	    		        g.drawImage(imageIcon.getImage(), 0, 0, null);
	    		        super.paintComponent(g);
	    		      }
	    		};
	    		l3[i].setFont(new Font(l3[i].getName(), Font.PLAIN, 40));
    		    l3[i].setForeground(Color.WHITE);
    		    l3[i].setText("      "+ " Set C");
	    		p3.add(l3[i]);
	    	}else{
	    		l3[i]= new JLabel() {
	    		      public void paintComponent(Graphics g) {
	    		        g.drawImage(imageIcon2.getImage(), 0, 0, null);
	    		        super.paintComponent(g);
	    		      }
	    		    };

	    		    l3[i].setOpaque(false);
	    		    l3[i].setFont(new Font(l3[i].getName(), Font.PLAIN, 30));
	    		    l3[i].setForeground(Color.WHITE);
	    		    //l3[i].setText("          "+ " Guest");
	    		    getContentPane().add( l3[i] );
	    		    p3.add(l3[i]);
	    	}
	    }
	    //----------------------------------------------------------------

		gPanel.setLayout(new GridLayout(0, 3));
		gPanel.setBackground(Color.DARK_GRAY);
		gPanel.add(p1);
		gPanel.add(p2);
		gPanel.add(p3);
		
		kkk.add(gPanel);
		this.add(gPanel);
		setSize(800,650);
		//setExtendedState(JFrame.MAXIMIZED_BOTH);
		setVisible(true);
		//this.validate();
		setTitle("Just One Moment");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
	public JPanel getLinkWork(){
		return gPanel;
	}
//	public void SetLabel1(){
//		l1[a].setText(contral.getShowQ2().toString());
//		a++;
//	}
//	public void SetLabel2(){
//		l2[b].setText(contral.getShowQ4().toString());
//		a++; 
//	}
//	public void SetLabel3(){
//		l3[c].setText(contral.getShowQ8().toString());
//		a++;
//	}
}
