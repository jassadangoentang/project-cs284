
public interface IAuthentication {
	//service
	boolean login(String username , String password)throws Exception;
	
}
