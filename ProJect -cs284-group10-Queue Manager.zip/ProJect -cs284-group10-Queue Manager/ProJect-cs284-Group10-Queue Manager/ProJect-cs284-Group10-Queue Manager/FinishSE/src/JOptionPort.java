import javax.swing.JOptionPane;

public class JOptionPort {
	DBConnection dbCon;
	Controler control;

	public JOptionPort() {

		dbCon = new DBConnection();

		String s = JOptionPane.showInputDialog(null, "Your port number is :", "Port Number", JOptionPane.PLAIN_MESSAGE,
				null, null, "").toString();
		if ((s != null) && (s.length() > 0)) {
			System.out.println(s);
			dbCon.setNumPort(s);
			// new ShowQueueOut();
			//RemainingTime vv = new RemainingTime(1,1,1);
			control = new Controler();
		}

		else {
			s = "5433";
			System.out.println(s);
			dbCon.setNumPort(s);
			control = new Controler();
			
		}
	}

	public static void main(String[] args) {
		new JOptionPort();
	}

}
