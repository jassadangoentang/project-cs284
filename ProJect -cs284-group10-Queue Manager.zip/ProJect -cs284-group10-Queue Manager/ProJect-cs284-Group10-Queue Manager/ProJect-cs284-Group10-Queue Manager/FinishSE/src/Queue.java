import java.beans.Customizer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Queue {

	private ArrayList<Person> customerQ;

	TableManagement tm = new TableManagement();
	private String phoneNumber;
	private int idQueue;
	private int amount;
	DBConnection dbConn;
	String sqlcommand;
	ResultSet result;
	int i = 1;

	public Queue() {
		dbConn = new DBConnection();
		this.customerQ = new ArrayList<Person>();
	}

	public int getidQueue() {

		dbConn.openConnection();

		System.out.println("Connection Success");

		sqlcommand = "SELECT \"idQueue\", \"Amount\", phone, email FROM \"Data\" ";
		result = dbConn.executeQueryStatement(sqlcommand);
		try {

			while (result.next()) {
				idQueue = Integer.valueOf(result.getString(1));
				// System.out.println(idQueue);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return idQueue;

	}

	public int getiAmount() {
		dbConn.openConnection();

		sqlcommand = "SELECT \"idQueue\", \"Amount\", phone, email FROM \"Data\" ";
		result = dbConn.executeQueryStatement(sqlcommand);
		try {

			while (result.next()) {
				amount = Integer.valueOf(result.getString(2));
				// System.out.println(amount);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return amount;

	}
	public String getPhoneNumber() {
		dbConn.openConnection();

		sqlcommand = "SELECT \"idQueue\", \"Amount\", phone, email FROM \"Data\" ";
		result = dbConn.executeQueryStatement(sqlcommand);
		try {

			while (result.next()) {
				phoneNumber = result.getString(3);
				// System.out.println(amount);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return phoneNumber;

	}

	public void clear() {
		this.customerQ.clear();

	}

	public boolean isEmpty() {
		if (customerQ.isEmpty())
			return true;
		else
			return false;
	}

	public boolean remove(Person p) {
		boolean flag = false;
		for (int i = 0; i < customerQ.size(); i++) {
			if (p.equals(customerQ.get(i))) {
				customerQ.remove(i);
				flag = true;
			}
		}
		return flag;
	}

	public void enQueue(Person p) {
		if (customerQ.size() == 0) {
			p.setIdQueue(1);
			customerQ.add(p);

		} else {
			p.setIdQueue(customerQ.get(customerQ.size() - 1).getIdQueue() + 1);
			customerQ.add(p);
		}

	}

	public Person deQueue() {
		Person p = customerQ.get(0);
		customerQ.get(0).DeleteDatabase();
		customerQ.remove(0);
		
		for (int i = 0; i < customerQ.size(); i++) {
			customerQ.get(i).setIdQueue(i);
		}
		return p;
	}

	public Person frontQ() throws EmptyQException{
		if (customerQ.size() == 0) {
			throw new EmptyQException();
		}
		return customerQ.get(0);
	}

	public Person lastQ() throws EmptyQException {
		if (customerQ.size() == 0) {
			throw new EmptyQException();
			
		} else if (customerQ.size() == 1) {
			return customerQ.get(0);
			
		} else {
			return customerQ.get(customerQ.size() - 1);
			
		}

	}

	public Person inQ(int i) {
		return customerQ.get(i);

	}

	public int queueSize() {
		return customerQ.size();

	}
	public void DeleteData(int x) {
		DBConnection dbConn = new DBConnection();
		dbConn.openConnection();

		System.out.println("Connection Success");
		
		String sqlcommand = "SELECT \"idQueue\", \"Amount\", phone, email FROM \"Data\" ";
		
		String sqll = "DELETE FROM \"Data\" WHERE \"idQueue\"= "+x+";";

		try {
			Connection cc = dbConn.openConnection2();
			Statement stm = cc.createStatement();
			stm.execute(sqll);
			System.out.println("out");
		} catch (SQLException ex) {
			System.out.println("error");

		}

	}
	// test Q
	/*
	 * public static void main(String[] args){ Queue q = new Queue();
	 * q.enQueue(new Person("A", 1, "09811123","@gsdfadf")); q.enQueue(new
	 * Person("A", 2, "09811123", "@gsdfadf")); q.enQueue(new Person("B", 1,
	 * "09811123", "@gsdfadf")); q.enQueue(new Person("C", 1, "09811123",
	 * "@gsdfadf")); q.enQueue(new Person("A", 3, "09811123", "@gsdfadf"));
	 * q.enQueue(new Person("A", 4, "09811123", "@gsdfadf"));
	 * 
	 * 
	 * }
	 */
}
