import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class AddTable extends JPanel {
	private JPanel northPanel, southPanel; // ���ź�,������ҧ
	private JLabel title, category, number, table;
	JRadioButton two; // ������ 2,4,8
	JRadioButton four;
	JRadioButton eight;
	JTextField amount; // �ӹҹ��з���ͧ�������
	public JButton ok;
	public JPanel p1, p2, p3,pAll; // ���ŷ�������southPanel
	public  IDtable mg=new IDtable();
	public AddTable() {
		pAll = new JPanel();
		BorderLayout bigPanel = new BorderLayout();
		this.setLayout(bigPanel);

		northPanel = new JPanel();
		northPanel.setBorder(BorderFactory.createTitledBorder(""));
		northPanel.setPreferredSize(new Dimension(400, 80));
		northPanel.setBackground(Color.darkGray);

		title = new JLabel("ADD TABLE");
		title.setFont(new Font("Tahoma", Font.BOLD, 40));
		title.setForeground(Color.WHITE);
		northPanel.add(title);

		two = new JRadioButton("Two Seats");
		four = new JRadioButton("Four Seats");
		eight = new JRadioButton("Eight Seats");
		ButtonGroup bg = new ButtonGroup();
		bg.add(two);
		bg.add(four);
		bg.add(eight);

		category = new JLabel("Category");
		category.setFont(new Font("Tahoma", Font.BOLD, 15));
		category.setForeground(Color.WHITE);

		number = new JLabel("Add :");
		number.setFont(new Font("Tahoma", Font.BOLD, 15));
		number.setForeground(Color.WHITE);

		southPanel = new JPanel();
		southPanel.setBorder(BorderFactory.createTitledBorder(""));
		southPanel.setPreferredSize(new Dimension(400, 80));
		southPanel.setLayout(new GridLayout(3, 0));
	
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		p1.add(category);
		p1.add(two);
		p1.add(four);
		p1.add(eight);

		
		amount = new JTextField(5);
		table = new JLabel("Table");
		table.setFont(new Font("Tahoma", Font.BOLD, 15));
		table.setForeground(Color.WHITE);
		p2.add(number);
		p2.add(amount);
		p2.add(table);
		
		ok = new JButton("OK");
		p3.add(ok);
		p1.setBorder(getBorder());
		
//				ok.addActionListener(this);


		p1.setBackground(Color.gray);
		p2.setBackground(Color.gray);
		p3.setBackground(Color.gray);
		southPanel.add(p1);
		southPanel.add(p2);
		southPanel.add(p3);
		
		pAll.setLayout(new GridLayout(2,0));
		pAll.add(northPanel);
		pAll.add(southPanel);
		

//		this.add(southPanel);
//
//		this.add(northPanel, BorderLayout.NORTH);
//
//		this.setBackground(Color.BLACK);
	}
	
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		if(two.isSelected()){
//			int x;
//			x=Integer.valueOf(amount.getText());
//
//			mg.tmg.max2+=x;
//			mg.two+=x;
//			mg.all+=x;
//			mg.keepNum+=x;
//			mg.keepNum2+=x;
//			mg.keepNum3+=x;
//
////			mg.addTable(2);
////			System.out.println(mg.two);
////			System.out.println(mg.tmg.WarningT2());
//
//		}else if(four.isSelected()){
//			int x;
//			x=Integer.valueOf(amount.getText());
//			mg.tmg.max4+=x;
//			mg.four+=x;
//
//			mg.all+=x;
//			mg.keepNum2+=x;
//			mg.keepNum3+=x;
////			System.out.println(mg.four);
//
//		}else if(eight.isSelected()){
//			int x;
//			x=Integer.valueOf(amount.getText());
//			mg.tmg.max8+=x;
//			mg.eight+=x;
//
//			mg.all+=x;
//			mg.keepNum3+=x;
////			System.out.println(mg.eight);
//
//		}
//		validate();
	
	
	
	
//
//		
//	}
//	public static void main(String[] args) {
//		JFrame frame = new JFrame();
//		AddTable adTable = new AddTable();
//		frame.setSize(400, 220);
//		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
//		frame.setVisible(true);
//		frame.add(adTable);
//
//	}

}
