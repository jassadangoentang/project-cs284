
public class Manager {
	public TableManagement tmg;
	public int two = 2;
	public int four = 2;
	public int eight = 2;
	public int all = 6;

	public Manager() {

		tmg = new TableManagement(two, four, eight, all);
	}

	public void addTable(int numpeople) {
		tmg.JongTable(numpeople);
	}

	public void PrintTable() {
		System.out.println(tmg.WarningT2());
		System.out.println(tmg.WarningT4());
		System.out.println(tmg.WarningT8());
	}

//	public static void main(String args[]) {
//		IDtable id = new IDtable();
//
//
//	}

}
