

public class AuthenticationController implements IAuthentication {

	@Override
	public boolean login(String username, String password) throws Exception {
		
		return false;
	}

}
