import javax.swing.JOptionPane;

public class IDtable extends Manager {
	public int[] IDtable;
	public int keepNum=0, keepNum2=0, keepNum3=0;
	public  int use2 = 0, use4 = 0, use8 = 0;

	public IDtable() {
		super();
//		this.IDtable = new int[super.tmg.max2 + super.tmg.max4 + super.tmg.max8 + 1];
	}

	public void setIDtable() {
//		IDtable = new int[tmg.max2 + tmg.max4 + tmg.max8 + 1];
		keepNum=0;
		keepNum2=0;
		keepNum3=0;
		for (int i = 1; i <= tmg.max2; i++) {
//			IDtable[i] = i;
			keepNum++;
		}
		//keepNum2 = keepNum;
		for (int i = keepNum + 1; i <= tmg.max2 + tmg.max4; i++) {
//			IDtable[i] = i;
			keepNum2++;
		}
		//keepNum3 = keepNum2;
		for (int i = keepNum+keepNum2+1; i <= tmg.max2 + tmg.max4 + tmg.max8; i++) {
//			IDtable[i] = i;
			keepNum3++;
		}
	}

	///// MAX
	public int getID2() {
		return keepNum;
	}

	public int getID4() {
		return keepNum2;
	}

	public int getID8() {
		return keepNum3;
	}

	public int use2() {
		return use2;
	}

	public int use4() {
		return use4;
	}

	public int use8() {
		return use8;
	}

	public int setuse2(int a) {
		
		if (use2 >= keepNum) {
			JOptionPane.showMessageDialog(null, "Full table2");
		}else{
			use2 += a;
		}
		return use2;
	}

	public int setuse4(int b) {

		if (use4 >= keepNum2) {
			JOptionPane.showMessageDialog(null, "Full table4");
		} else {
			use4 += b;
		}
		return use4;
	}

	public int setuse8(int c) {

		if (use8 >= keepNum3) {
			JOptionPane.showMessageDialog(null, "Full table8");
		} else {
			use8 += c;
		}
		return use8;
	}public boolean isfull2(){

		if (use2 >= keepNum3) {
			return true;
		} else{
			return false;
		}
		
	}public boolean isfull4(){

		if (use4 >= keepNum3) {
			return true;
		} else{
			return false;
		}
		
	}
	public boolean isfull8(){

		if (use8 >= keepNum3) {
			return true;
		} else{
			return false;
		}
		
	}
}
